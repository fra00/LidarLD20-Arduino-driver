#include "PointData.h"

PointData::PointData(float angle,int distance, int intensity) {
  this->angle = angle;
  this->distance = distance;
  this->intensity = intensity;
}

void PointData::print() {
  
}
